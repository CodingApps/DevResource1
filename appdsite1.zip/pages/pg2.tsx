import EventPage from "@/components/event-page"

export default function Home() {
  return <EventPage />
}

