import React from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { MapPin, Clock } from "lucide-react"
import { HostSidebar } from "./host-sidebar"
import { PhotoGrid } from "./photo-grid"

// ... (keep the existing photos array)

export default function EventPage() {
  // ... (keep the existing component code)
}

