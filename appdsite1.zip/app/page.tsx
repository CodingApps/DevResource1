"use client"

import EventPage from "../page"

export default function SyntheticV0PageForDeployment() {
  return <EventPage />
}